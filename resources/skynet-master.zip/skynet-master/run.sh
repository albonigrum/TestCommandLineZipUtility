#!/bin/bash

python3 /Users/alevine/eclipse-workspace/statop/monitor_envoy_stats.py /Users/alevine/testrun -p productpage-v1 ratings-v1 reviews-v1 reviews-v2 reviews-v3 details-v1
