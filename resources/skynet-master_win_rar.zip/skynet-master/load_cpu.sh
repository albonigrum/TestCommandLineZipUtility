#!/bin/bash

/host/stress_cpu_mem.sh
