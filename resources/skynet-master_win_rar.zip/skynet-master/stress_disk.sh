#!/bin/bash

sudo dd if=/dev/sda of=/dev/null bs=4k count=1000000